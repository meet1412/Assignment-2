<style>
nav{
    background-image: url(img/std.png);
    background-size: cover;
    background-position: center;
}
nav{
    position: absolute;
    top: 0%;
    left: 0%;
    padding-top: 25px;
    padding-bottom: 25px;
    height: 200px;
    width: 100%;
    background-color: whitesmoke;
}
ul{
    list-style-type: none;
    position: relative;
    cursor: pointer;
    height: fit-content;
    width: fit-content;
}
.menu{
    font-size: 50px;
    font-family: 'Arial', sans-serif;
    font-weight: 700;
    transition: all 0.5s ease-in-out;
    color: #292B33;
}
.hidden{
    display: none;
}
.menu:hover{
    font-family: 'Fira Sans', sans-serif;
    font-family: 'Young Serif', serif;
    font-size: 60px;
    box-shadow: 5px 5px 10px black, -5px -5px 10px black;
    border-radius: 0.5cm;
    padding: 15px;
}
.menu:hover ul{
    display: contents;
    font-size: 30%;
}
a{
    text-decoration: line-through;
    color: #292B33;
} 
a:hover{
    text-decoration: none;  
    color:burlywood;
}
</style>

<nav>
    <ul>
        <li class="menu">Menu
            <ul class="hidden">
                <li><a href="index.php">Sign Up</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="view_2.php">View</a></li>
            </ul>
        </li>
    </ul>
</nav>
