<style>
    footer{
        position: static;
        bottom: 0;
        left: 0;
        right: 0;
        height: 80px;
        align-content: center;
        color:white;
        text-align: center;
    }
    h1{
        font-size: 100%;
        font-family: algerian;
        font-weight: bolder;
    }
</style>

<footer>
    <h1>End Of Form</h1>
</footer>