<?php
include 'inc/header.php';
session_start();
?>
<?php
require_once('database.php');
$database = new database();
$data = $database->displayData();

if(!empty($_GET['id'])) {
    $deleteId = $_GET['id'];
    $database->deleteRecord($deleteId);
}
?>

<style>
html{
    background-color: slategray;
}
.data{
    margin-top: 20%;
    background-color: white;
    height: auto;
    width: 46%;
    margin-left: auto;
    margin-right: auto;
    padding-left: 20px;
    padding-top: 15px;
    padding-bottom: 15px;
    padding-right: 10px;
    font-size: larger;
    border-radius: 0.5cm;
    box-shadow: 5px 5px 1px black, -5px -5px 1px black;
}
strong{
    color: darkslategrey;
    text-transform: uppercase;
}
th{
    padding: 10px;
    font-size: 100%;
}
td{
    padding: 10px;    
}
button{
    border: none;
    padding: 10px 20px;
    color: white;
    cursor: pointer;
    background-color: slategray;
    margin-left: 1px;
    border-radius: 1cm;
}
button:hover{
    background-color: #292B33;
}
</style>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <title>View Student Records</title>
</head>
<body>

<div class="data">
    <table class="data-table">
    <a href="add.php"><button type="submit">ADD DATA</button></a>
    <a href="image.php"><button type="submit">Upload Image</button></a>
    <a href='logout.php'><button>Logout</button></a>
        <tr class="m">
            <th>ID</th>
            <th class="f">First Name</th>
            <th class="l">Last Name</th>
            <th class="i">Student_ID</th>
            <th class="s">Semester</th>
            <th class="g">Grade</th>
            <th class="e">Edit</th>
            <th class="d">Delete</th>
        </tr>
        <?php
        if (!empty($data)) {
            foreach ($data as $row) {
                ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td class="f"><?php echo $row['fname']; ?></td>
                    <td class="l"><?php echo $row['lname']; ?></td>
                    <td class="i"><?php echo $row['StdID']; ?></td>
                    <td class="s"><?php echo $row['sem']; ?></td>
                    <td class="g"><?php echo $row['grade']; ?></td>
                    <td class="e">
                        <a href="update.php?id=<?php echo $row['id'] ?>">
                            <button>Edit</button>
                        </a>
                    </td>
                    <td class="d">
                    <a href="view.php?id=<?php echo $row['id'] ?>" onclick="return confirm('Are you sure?'); return false;">
                        <button>Delete</button>
                    </a>
                    </td>
                </tr>
                <?php
            }
        } else {
            echo "<tr><td colspan='5'>No records found</td></tr>";
        }
        $conn = null;
        ?>
    </table>
</div>

</body>
</html>
<?php
require 'inc/footer.php';
?>