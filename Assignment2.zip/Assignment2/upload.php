<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_FILES["file"]) && $_FILES["file"]["error"] == 0) {
        
        $path = "images/";
        
        if (!is_dir($path)) {
            mkdir($path, 0755, true);
        }
        
        $fileName = basename($_FILES["file"]["name"]);
        $filePath = $path . $fileName;
        
        if (!file_exists($filePath)) {
            move_uploaded_file($_FILES["file"]["tmp_name"], $filePath);
            echo "The file $fileName has been uploaded.";
            header('Location: view.php');
        } else {
            echo "File already exists. Please choose a different file.";
        }
    } else {
        echo "Error uploading file. Please try again.";
    }
}
?>
