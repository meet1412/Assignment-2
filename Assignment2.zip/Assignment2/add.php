<?php
require 'inc/header.php';
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8"/>
        <title>
            Student Records
        </title>
        <link rel="stylesheet" href="css/styles.css"/>

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Fira+Sans:ital@1&family=Young+Serif&display=swap" rel="stylesheet">
    </head>
<body> 
    <main> 
    <form method="post">

        <div class="title">
            Student Records
        </div>

        <div>
            <input type="text" name="fname" id="fname" placeholder="First Name" required/>
        </div>

        <div>
            <input type="text" name="lname" id="lname" placeholder="Last Name" required/>  
        </div>

        <div>
            <input type="text" name="StdID" id="StdID" placeholder="Student ID" required/>
        </div>
        
        <div>
            <input type="number" name="sem" id="sem" min="1" max="5" placeholder="Semester" required/>  
        </div>

        <div>
            <input type="text" name="grade" id="grade" placeholder="Total GPA" required/>
        </div>

        <div class="button">
            <a href="view.php"><button type="submit">Submit</button></a>
            <a href="view.php"><button type="button">Cancel</button></a>
            <button type="reset">Reset</button>
        </div>
    </form>
    
    <?php
    require_once('database.php');

    if (!empty($_POST)) {
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $StdID = $_POST['StdID'];
        $sem = $_POST['sem'];
        $grade = $_POST['grade'];
        
        $database = new database(); 

        $result = $database->insertData($fname, $lname, $StdID, $sem, $grade);
        if ($result) {
            echo "<p>Successfully inserted data</p>";
            Header('Location: view.php');
        } else {
            echo "<p>Failed to insert data</p>";
            Header('Location: view.php');
        }
        Header('Location: view.php');
    }
?>
    </main> 
</body>
</html>
<?php
require 'inc/footer.php';
?> 