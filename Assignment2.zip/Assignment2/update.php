<?php
require 'inc/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <title>Update Student Records</title>
    <link rel="stylesheet" href="css/styles.css"/>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fira+Sans:ital@1&family=Young+Serif&display=swap" rel="stylesheet">
</head>
<body>
    <main>

        <?php
        require_once('database.php');

        if (isset($_GET['id'])) {
            $id = $_GET['id'];

            $database = new database();

            $record = $database->displayRecordById($id);

            if ($record) {
        ?>
                <form method="post">
                    <div class="title">
                        Update Student Record
                    </div>

                    <div>
                        <input type="text" name="fname" id="fname" placeholder="First Name" value="<?php echo $record['fname']; ?>"/>
                    </div>

                    <div>
                        <input type="text" name="lname" id="lname" placeholder="Last Name" value="<?php echo $record['lname']; ?>"/>
                    </div>

                    <div>
                        <input type="text" name="StdID" id="StdID" placeholder="Student ID" value="<?php echo $record['StdID']; ?>"/>
                    </div>

                    <div>
                        <input type="number" name="sem" id="sem" min="1" max="5" placeholder="Semester" value="<?php echo $record['sem']; ?>"/>
                    </div>

                    <div>
                        <input type="text" name="grade" id="grade" placeholder="Total GPA" value="<?php echo $record['grade']; ?>"/>
                    </div>

                    <div class="button">
                        <a href="view.php"><button type="submit">Update</button></a>
                        <a href="view.php"><button type="button">Cancel</button></a>
                    </div>
                </form>
                <?php

                if (!empty($_POST)) {
                    $new_fname = $_POST['fname'];
                    $new_lname = $_POST['lname'];
                    $new_StdID = $_POST['StdID'];
                    $new_sem = $_POST['sem'];
                    $new_grade = $_POST['grade'];

                    $result = $database->updateRecord($id, $new_fname, $new_lname, $new_StdID, $new_sem, $new_grade);
                }
            } 
        } 
        ?>
    </main>
</body>
</html>
<?php
require 'inc/footer.php';
?>