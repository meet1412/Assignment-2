<?php
require 'inc/header.php';
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8"/>
        <title>
            Student Records
        </title>
        <link rel="stylesheet" href="css/styles.css"/>

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Fira+Sans:ital@1&family=Young+Serif&display=swap" rel="stylesheet">
    </head>
<body> 
    <main> 
    <form method="post" action="inc/validate.php">

        <div class="title">
            Login
        </div>

        <div>
            <input type="text" name="uname" id="uname" placeholder="User Name"/>
        </div>

        <div>
            <input type="password" name="pass" id="pass" placeholder="Password"/>  
        </div>

        <div class="button">
            <button type="submit">Login</button>
            <button type="reset">Reset</button>
        </div>
    </form>
    </main>
    
</body>
</html>
<?php
require 'inc/footer.php';
?>