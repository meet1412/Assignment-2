<?php
require 'inc/header.php';
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8"/>
        <title>
            Student Records
        </title>
        <link rel="stylesheet" href="css/styles.css"/>

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Fira+Sans:ital@1&family=Young+Serif&display=swap" rel="stylesheet">
    </head>
<body> 
    <main> 

    <form action="upload.php" method="post" enctype="multipart/form-data">
        <label for="file">Select Image:</label>
        <input type="file" name="file" id="file" accept="image/*" required>
        <br>
        <button type="submit" name="submit">Upload Image</button>
        <a href="view.php"><button type="button">Cancel</button></a>
    </form>
    
    </main>
    
</body>
</html>
<?php
require 'inc/footer.php';
?>