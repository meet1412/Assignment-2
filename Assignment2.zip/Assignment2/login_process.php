<?php 
    include('database.php');
    $database = new database();
    $conn = $database->con;
?>
<?php
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
    $username= $_POST['uname'];
    $password = $_POST['pass'];

    if (true){
		$password = hash('sha512', $password);
		$sql = "INSERT INTO users (first_name, last_name, username, password) VALUES ('$fname', '$lname',' $username', '$password');";
		$conn->query($sql);
    	echo '<section class="success-row">';
		echo '<div>';
		echo '<h3>Admin Saved</h3>';
		echo '</div>';
    	echo '</section>';
		header("Location: view.php"); 
		
	}
?>